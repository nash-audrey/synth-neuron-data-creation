
##### Finding beta distributions for phase coding #####


##### Phase Template 1 #####

alpha <- 1
beta <- 1
plot_pdf <- function(x) {
  dbeta(x, alpha, beta)
}
curve(plot_pdf, from=0, to=1, main='Phase Template 1', xlab='Time in Lick Interval', ylab='P(Spike)', xaxt='n', yaxt='n')
# X-axis
axis(1, at = c(0, .20, .40, .60, .80, 1), labels=c(1, 20, 40, 60, 80, 100))


##### Phase Template 2 #####

constraints <- function(par) {
  
  c1 <- (pbeta(.75, par[1], par[2]) - pbeta(.25, par[1], par[2]) - .9)^2
  
  c2 <- (dbeta(.25, par[1], par[2]) - dbeta(.75, par[1], par[2]))^2
  
  return(c1 + c2)
}

results <- optim(c(1,2), constraints)$par
alpha <- results[1]
beta <- results[2]
plot_pdf <- function(x) {
  dbeta(x, alpha, beta)
}
curve(plot_pdf, from=0, to=1, main='Phase Template 2', xlab='Time in Lick Interval', ylab='P(Spike)', xaxt='n', yaxt='n')
# X-axis
axis(1, at = c(0, .20, .40, .60, .80, 1), labels=c(1, 20, 40, 60, 80, 100))

##### Phase Template 3 #####

constraints <- function(par) {
  
  c1 <- (pbeta(.5, par[1], par[2]) - .95)^2
  
 # c2 <- (dbeta(0, par[1], par[2]))^2
  
  c3 <- ( (par[1])/(par[1] + par[2]) - .25)^2
  
  return(c1 + c3)
}


results <- optim(c(1,2), constraints)$par
alpha <- results[1]
beta <- results[2]
plot_pdf <- function(x) {
  dbeta(x, alpha, beta)
}
curve(plot_pdf, from=0, to=1, main='Phase Template 3', xlab='Time in Lick Interval', ylab='P(Spike)', xaxt='n', yaxt='n')
# X-axis
axis(1, at = c(0, .20, .40, .60, .80, 1), labels=c(1, 20, 40, 60, 80, 100))


##### Phase Template 4 #####

constraints <- function(par) {
  
  c1 <- (pbeta(1, par[1], par[2]) - pbeta(.5, par[1], par[2]) - .95)^2
  
  #c2 <- (dbeta(1, par[1], par[2]))^2
  
  c3 <- ( (par[1])/(par[1] + par[2]) - .75)^2
  
  return(c1 + c3)
}

results <- optim(c(1,2), constraints)$par
alpha <- results[1]
beta <- results[2]
plot_pdf <- function(x) {
  dbeta(x, alpha, beta)
}
curve(plot_pdf, from=0, to=1, main='Phase Template 4', xlab='Time in Lick Interval', ylab='P(Spike)', xaxt='n', yaxt='n')
# X-axis
axis(1, at = c(0, .20, .40, .60, .80, 1), labels=c(1, 20, 40, 60, 80, 100))



##### Phase Template 5 #####

constraints <- function(par) {
  
  c1 <- (pbeta(.2, par[1], par[2]) - .9)^2
  
  c2 <- (dbeta(0, par[1], par[2]))^2
  
  return(c1 + c2)
}

results <- optim(c(1,2), constraints)$par
alpha <- results[1]
beta <- results[2]
plot_pdf <- function(x) {
  dbeta(x, alpha, beta)
}
curve(plot_pdf, from=0, to=1, main='Phase Template 5', xlab='Time in Lick Interval', ylab='P(Spike)', xaxt='n', yaxt='n')
# X-axis
axis(1, at = c(0, .20, .40, .60, .80, 1), labels=c(1, 20, 40, 60, 80, 100))


##### Phase Template 6 #####

constraints <- function(par) {
  
  c1 <- (pbeta(.4, par[1], par[2]) - pbeta(.2, par[1], par[2]) - .9)^2
  
  c2 <- (dbeta(.2, par[1], par[2]) - dbeta(.4, par[1], par[2]))^2
  
  return(c1 + c2)
}

results <- optim(c(1,2), constraints)$par
alpha <- results[1]
beta <- results[2]
plot_pdf <- function(x) {
  dbeta(x, alpha, beta)
}
curve(plot_pdf, from=0, to=1, main='Phase Template 6', xlab='Time in Lick Interval', ylab='P(Spike)', xaxt='n', yaxt='n')
# X-axis
axis(1, at = c(0, .20, .40, .60, .80, 1), labels=c(1, 20, 40, 60, 80, 100))


##### Phase Template 7 #####

constraints <- function(par) {
  
  c1 <- (pbeta(.6, par[1], par[2]) - pbeta(.4, par[1], par[2]) - .9)^2
  
  c2 <- (dbeta(.6, par[1], par[2]) - dbeta(.4, par[1], par[2]))^2
  
  return(c1 + c2)
}

results <- optim(c(1,2), constraints)$par
alpha <- results[1]
beta <- results[2]
plot_pdf <- function(x) {
  dbeta(x, alpha, beta)
}
curve(plot_pdf, from=0, to=1, main='Phase Template 7', xlab='Time in Lick Interval', ylab='P(Spike)', xaxt='n', yaxt='n')
# X-axis
axis(1, at = c(0, .20, .40, .60, .80, 1), labels=c(1, 20, 40, 60, 80, 100))


##### Phase Template 8 #####

constraints <- function(par) {
  
  c1 <- (pbeta(.8, par[1], par[2]) - pbeta(.6, par[1], par[2]) - .9)^2
  
  c2 <- (dbeta(.8, par[1], par[2]) - dbeta(.6, par[1], par[2]))^2
  
  return(c1 + c2)
}

results <- optim(c(1,2), constraints)$par
alpha <- results[1]
beta <- results[2]
plot_pdf <- function(x) {
  dbeta(x, alpha, beta)
}
curve(plot_pdf, from=0, to=1, main='Phase Template 8', xlab='Time in Lick Interval', ylab='P(Spike)', xaxt='n', yaxt='n')
# X-axis
axis(1, at = c(0, .20, .40, .60, .80, 1), labels=c(1, 20, 40, 60, 80, 100))



##### Phase Template 9 #####

constraints <- function(par) {
  
  c1 <- (pbeta(1, par[1], par[2]) - pbeta(.8, par[1], par[2]) - .9)^2
  
  c2 <- (dbeta(1, par[1], par[2]))^2
  
  return(c1 + c2)
}

results <- optim(c(1,2), constraints)$par
alpha <- results[1]
beta <- results[2]
plot_pdf <- function(x) {
  dbeta(x, alpha, beta)
}
curve(plot_pdf, from=0, to=1, main='Phase Template 9', xlab='Time in Lick Interval', ylab='P(Spike)', xaxt='n', yaxt='n')
# X-axis
axis(1, at = c(0, .20, .40, .60, .80, 1), labels=c(1, 20, 40, 60, 80, 100))







